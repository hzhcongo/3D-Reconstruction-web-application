#ifndef __H5ZBZIP2_H__
#define __H5ZBZIP2_H__ 1

#define FILTER_BZIP2 307
int register_bzip2(char **version, char **date);

#endif /* ! defined __H5ZBZIP2_H__ */
